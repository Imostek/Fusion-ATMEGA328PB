#include "DAC.h"

//define constructor
DAC::DAC(SPIMaster *spimaster)
{
    this->spimaster = spimaster;
    spimaster->begin();
    // rst fpga
    spimaster->transfer(250); //send address
    spimaster->transfer(0);
}

//begin method
void DAC::begin(){
    spimaster->transfer(0x10);//send DAC address
    spimaster->transfer(0x08);//see notes for data format
    spimaster->transfer(0x10);//send DAC address
    spimaster->transfer(0x08);
}

//end method
void DAC::end(){
    spimaster->transfer(0x10);//send DAC address
    spimaster->transfer(0x00);//see notes for data format
    spimaster->transfer(0x10);//send DAC address
    spimaster->transfer(0x00);
}

//write mehtod
void DAC::write(uint8_t dt){
    spimaster->transfer(130);
    spimaster->transfer(dt);
}
