#ifndef UART_H
#define UART_H

#include <SPI_master.h>
#include "string.h"
#include "stdlib.h"

class UART {
private:
  SPIMaster* spimaster;

public:
    UART(SPIMaster*);
    void begin();
    void end();
    void printChar(uint8_t);
    void printStr(String str);
    void printInt(int number);
    void printFloat(float number);
    void println(char str[]);
    void fromADC();
};

#endif