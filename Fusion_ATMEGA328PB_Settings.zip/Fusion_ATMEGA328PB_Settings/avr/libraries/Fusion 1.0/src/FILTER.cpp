#include "FILTER.h"

// define constructor
FILTER::FILTER(SPIMaster *spimaster){
    this->spimaster = spimaster;
    spimaster->begin();

    // rst fpga
    spimaster->transfer(250); //send address
    spimaster->transfer(0);

    //init coeff val
    this->coeff_0   = 0x0000;
    this->coeff_1   = 0x0000;
    this->coeff_2   = 0x0000;
    this->coeff_3   = 0x0000;
    this->coeff_4   = 0x0000;
    this->coeff_5   = 0x0000;
    this->coeff_6   = 0x0000;
}

//define begin method
void FILTER::begin(){
    //config ADC controller    
    spimaster->transfer(0x04);
    spimaster->transfer(0x05);
    spimaster->transfer(0x04);
    spimaster->transfer(0x05); 

    //config UART controller
    spimaster->transfer(0x08);
    spimaster->transfer(0x28);
    spimaster->transfer(0x08);
    spimaster->transfer(0x28);    
}

// update coeff method
void FILTER::updateCoeff(byte coeff_no, uint16_t coeff_val){
    uint8_t coeff_lsb, coeff_msb;
    coeff_lsb = (byte)(coeff_val & 0xff);
    coeff_msb = (byte)((coeff_val & 0xff00) >> 8);
    switch (coeff_no){
        case 0: coeff_0 = coeff_val; 
                spimaster->transfer(160);
                spimaster->transfer(coeff_lsb);
                spimaster->transfer(160);
                spimaster->transfer(coeff_lsb);
                spimaster->transfer(161);
                spimaster->transfer(coeff_msb);
                spimaster->transfer(161);
                spimaster->transfer(coeff_msb);
                break;
        case 1: coeff_1 = coeff_val; 
                spimaster->transfer(162);
                spimaster->transfer(coeff_lsb);
                spimaster->transfer(162);
                spimaster->transfer(coeff_lsb);                
                spimaster->transfer(163);
                spimaster->transfer(coeff_msb);
                spimaster->transfer(163);
                spimaster->transfer(coeff_msb);                
                break;
        case 2: coeff_2 = coeff_val; 
                spimaster->transfer(164);
                spimaster->transfer(coeff_lsb);
                spimaster->transfer(164);
                spimaster->transfer(coeff_lsb);                
                spimaster->transfer(165);
                spimaster->transfer(coeff_msb);
                spimaster->transfer(165);
                spimaster->transfer(coeff_msb);                
                break;
        case 3: coeff_3 = coeff_val; 
                spimaster->transfer(166);
                spimaster->transfer(coeff_lsb);
                spimaster->transfer(166);
                spimaster->transfer(coeff_lsb);
                spimaster->transfer(167);
                spimaster->transfer(coeff_msb);
                spimaster->transfer(167);
                spimaster->transfer(coeff_msb);                
                break;
        case 4: coeff_4 = coeff_val; 
                spimaster->transfer(168);
                spimaster->transfer(coeff_lsb);
                spimaster->transfer(168);
                spimaster->transfer(coeff_lsb);                
                spimaster->transfer(169);
                spimaster->transfer(coeff_msb);
                spimaster->transfer(169);
                spimaster->transfer(coeff_msb);                
                break;
        case 5: coeff_5 = coeff_val; 
                spimaster->transfer(170);
                spimaster->transfer(coeff_lsb);
                spimaster->transfer(170);
                spimaster->transfer(coeff_lsb);                
                spimaster->transfer(171);
                spimaster->transfer(coeff_msb);
                spimaster->transfer(171);
                spimaster->transfer(coeff_msb);                
                break;
        case 6: coeff_6 = coeff_val; 
                spimaster->transfer(172);
                spimaster->transfer(coeff_lsb);
                spimaster->transfer(172);
                spimaster->transfer(coeff_lsb);                
                spimaster->transfer(173);
                spimaster->transfer(coeff_msb);
                spimaster->transfer(173);
                spimaster->transfer(coeff_msb);                
                break; 
    }
}

//define set coeff method
void FILTER::setCoeff(){
    spimaster->transfer(174);
    spimaster->transfer(0x55);
}

// define get coeff method
uint16_t FILTER::getCoeff(byte coeff_no){
    uint16_t coeff_val;
    switch (coeff_no){
        case 0: coeff_val = coeff_0; break;
        case 1: coeff_val = coeff_1; break;
        case 2: coeff_val = coeff_2; break;
        case 3: coeff_val = coeff_3; break;
        case 4: coeff_val = coeff_4; break;
        case 5: coeff_val = coeff_5; break;
        case 6: coeff_val = coeff_6; break;
    }
    return(coeff_val);
}