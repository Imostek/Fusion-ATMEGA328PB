#ifndef OV7670_H
#define OV7670_H

#include <Arduino.h>
#include <avr/pgmspace.h>
#include <OV7670RegDefination.h>

//define OV7670 class
class OV7670
{
private:
    byte SCL;
    byte SDATA;
    byte FP_RST;

    //define internal variable
    byte brightVar;
    byte contrastVar;
    byte rGain;
    byte bGain;
    byte gGain;
    byte UchGain;
    byte VchGain;
    byte TSLB;
    byte COM16;
    byte EDGE;

public:
    OV7670(byte, byte, byte);
    void initState();
    void writeReg(byte, byte);
    void writeReglist(const struct regval_list[]);
    void begin();

    //define set methods
    void setBrightness(int16_t val);
    void setContrast(byte val);
    void setBluegain(byte val);
    void setRedgain(byte val);
    void setGreengain(byte val);
    void setAutoUV();
    void setNegImage();
    void resetImage();
    void setUgain(byte val);
    void setVgain(byte val);
    void setSharpness(byte val);

    //define get methods
    byte getBrightness();
    byte getContrast();
    byte getBluegain();
    byte getRedgain();
    byte getGreengain();
    byte getUgain();
    byte getVgain();
    byte getSharpness();
};

#endif