#include "UART.h"

using namespace std;

//define constructor
UART::UART(SPIMaster *spimaster)
{
    this->spimaster = spimaster;
    spimaster->begin();
}

//begin method
void UART::begin(){
    spimaster->transfer(0x08);//send UART address
    spimaster->transfer(0x08);//see notes for data format
    spimaster->transfer(0x129);//rst uart buffers
    spimaster->transfer(0x00); //dummy data
}

//end method
void UART::end(){
    spimaster->transfer(0x08);//send UART address
    spimaster->transfer(0x00);//see notes for data format
    spimaster->transfer(0x08);
    spimaster->transfer(0x00);
}

//print char
void UART::printChar(uint8_t ch){
    spimaster->transfer(128);
    spimaster->transfer(ch);
}

//print string
void UART::printStr(String str){
    for(int i=0; str[i]!='\0'; i++) UART::printChar(str[i]);
}

//print number
void UART::printInt(int number){
    String str = String(number);
    for(int i=0; str[i]!='\0'; i++) UART::printChar(str[i]);
}

//print float
void UART::printFloat(float number){
    String str = String(number);
    for(int i=0; str[i]!='\0'; i++) UART::printChar(str[i]);
}

//print string with New Line and CR
void UART::println(char str[]){
    UART::printStr(str);
    UART::printChar('\n');
    UART::printChar('\r');
}

//fromADC method
void UART::fromADC(){
    spimaster->transfer(0x08);
    spimaster->transfer(0x18);
    spimaster->transfer(0x08);
    spimaster->transfer(0x18);
}

