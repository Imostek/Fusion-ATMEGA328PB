#include "ADC08.h"

//define constructor
ADC08::ADC08(SPIMaster *spimaster)
{
    this->spimaster = spimaster;
    spimaster->begin();
}

//begin method
void ADC08::begin(){
    spimaster->transfer(0x04);//send ADC address
    spimaster->transfer(0x09);//see notes for data format
}

//end method
void ADC08::end(){
    spimaster->transfer(0x04);//send ADC address
    spimaster->transfer(0x00);//see notes for data format
}

//read mehtod
uint8_t ADC08::read(){
    uint8_t val;
    spimaster->transfer(0x04);
    val = spimaster->transfer(0x01);
    return(val);
}

//to UART method
void ADC08::toUART(){
    spimaster->transfer(0x04);
    spimaster->transfer(0x03);
}