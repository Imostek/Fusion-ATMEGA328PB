#include "PWM.h"


//define constructor
PWM::PWM(SPIMaster *spimaster)
{
    this->spimaster = spimaster;
    this->mem = 0x00;
    spimaster->begin();     
}

//begin method
void PWM::begin(uint8_t pwm_no){
    mem = mem | pwm_no;
    spimaster->transfer(32); //send address
    spimaster->transfer(mem); //send data
}

//end method
void PWM::end(uint8_t pwm_no){
    uint8_t dt = 255 - pwm_no;
    mem = mem & dt;
    spimaster->transfer(32);  //send address
    spimaster->transfer(mem); //send data
    spimaster->transfer(255); //send dummy address
    spimaster->transfer(0);   //send data
}

//write command method
bool PWM::writeCMD(uint8_t pwm_no, uint8_t cmd){
    switch (pwm_no)
    {
    case 0x02:  spimaster->transfer(140);//send address
                spimaster->transfer(cmd);//send data
                return(true);
                break;

    case 0x04:  spimaster->transfer(141);//send address
                spimaster->transfer(cmd);//send data
                return(true);
                break;            
    
    case 0x08:  spimaster->transfer(142);//send address
                spimaster->transfer(cmd);//send data
                return(true);
                break; 

    case 0x10:  spimaster->transfer(143);//send address
                spimaster->transfer(cmd);//send data
                return(true);
                break;  

    default:    return(false);
                break;                               
    }
}
