#ifndef DAC_H
#define DAC_H

#include <SPI_master.h>

class DAC {
private:
  SPIMaster* spimaster;

public:
    DAC(SPIMaster*);
    void begin();
    void end();
    void write(uint8_t);
};

#endif