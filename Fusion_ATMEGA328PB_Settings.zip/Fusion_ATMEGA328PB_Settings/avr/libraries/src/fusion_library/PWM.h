#ifndef PWM_H
#define PWM_H

#include <SPI_master.h>

#define PWM1 0x02
#define PWM2 0x04
#define PWM3 0x08
#define PWM4 0x10

class PWM {
private:
  SPIMaster* spimaster;
  byte mem;

public:
    PWM(SPIMaster*);
    void begin(uint8_t);
    void end(uint8_t);
    bool writeCMD(uint8_t, uint8_t);
};

#endif