#include "LED.h"

//define constructor
LED::LED(SPIMaster *spimaster)
{
    this->spimaster = spimaster;
    this->mem = 0x0f;
    spimaster->begin();
}

//on method
void LED::on(uint8_t dt){
    mem = mem & dt & 0x0f;
    spimaster->transfer(0x01); //send address
    spimaster->transfer(mem); //send data
}

//off method
void LED::off(uint8_t dt){
    uint8_t data = dt & 0x0f;
    data = data ^ 0x0f;
    mem = data | mem;
    spimaster->transfer(0x01); //send address
    spimaster->transfer(mem); //send data
}