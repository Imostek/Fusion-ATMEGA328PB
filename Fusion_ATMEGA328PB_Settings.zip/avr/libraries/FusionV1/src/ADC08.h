#ifndef ADC08_H
#define ADC08_H

#include <SPI_master.h>

class ADC08 {
private:
  SPIMaster* spimaster;

public:
    ADC08(SPIMaster*);
    void begin();
    void end();
    uint8_t read();
    void toUART();
};

#endif