#ifndef LED_H
#define LED_H

#include <SPI_master.h>

class LED {
private:
  SPIMaster* spimaster;
  byte mem;

public:
    LED(SPIMaster* );
    void on(uint8_t );
    void off(uint8_t );
};

#endif