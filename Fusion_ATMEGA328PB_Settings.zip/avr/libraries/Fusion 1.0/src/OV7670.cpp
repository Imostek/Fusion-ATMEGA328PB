#include "OV7670.h"

OV7670::OV7670(byte SCL, byte SDATA, byte FP_RST){
    this->SCL    = SCL;
    this->SDATA  = SDATA;
    this->FP_RST = FP_RST;

    // variable init
    this-> brightVar   = 0x00;
    this-> contrastVar = 0x00;
    this-> rGain       = 0x00;
    this-> bGain       = 0x00;
    this-> bGain       = 0x00;
    this-> UchGain     = 0x00;
    this-> VchGain     = 0x00;
    this->TSLB         = 0x00;
    this->COM16        = 0x00;
    this->EDGE         = 0x00;         
}

// initstate method
void OV7670::initState(){
    pinMode(SCL, OUTPUT);
    pinMode(SDATA, OUTPUT);
    pinMode(FP_RST, OUTPUT);

    //init pins
    digitalWrite(SCL, HIGH);
    digitalWrite(SDATA, HIGH);
    digitalWrite(FP_RST, HIGH);
}

// write reg method
void OV7670::writeReg(byte addr, byte dt){
    byte i=0;
    byte data = 0x80;
    byte d_addr = 0x42;
    digitalWrite(SCL, HIGH);
    digitalWrite(SDATA, HIGH);

    digitalWrite(SDATA, LOW);
    delayMicroseconds(2);
    digitalWrite(SCL, LOW);
    delayMicroseconds(2);  

    for(i=0; i<8; i++){
        if(data & d_addr) digitalWrite(SDATA, HIGH);
        else              digitalWrite(SDATA, LOW);
        delayMicroseconds(2);
        digitalWrite(SCL, HIGH);
        delayMicroseconds(4);
        digitalWrite(SCL, LOW);
        delayMicroseconds(2);
        data = data >> 1;  
    }

    digitalWrite(SDATA, HIGH);
    delayMicroseconds(2);
    digitalWrite(SCL, HIGH);
    delayMicroseconds(4);
    digitalWrite(SCL, LOW);
    delayMicroseconds(2);

    data = 0x80;
    for(i=0; i<8; i++){
        if(data & addr) digitalWrite(SDATA, HIGH);
        else            digitalWrite(SDATA, LOW);
        delayMicroseconds(2);
        digitalWrite(SCL, HIGH);
        delayMicroseconds(4);
        digitalWrite(SCL, LOW);
        delayMicroseconds(2);
        data = data >> 1;  
    }

    digitalWrite(SDATA, HIGH);
    delayMicroseconds(2);
    digitalWrite(SCL, HIGH);
    delayMicroseconds(4);
    digitalWrite(SCL, LOW);
    delayMicroseconds(2);

    data = 0x80;
    for(i=0; i<8; i++){
        if(data & dt) digitalWrite(SDATA, HIGH);
        else          digitalWrite(SDATA, LOW);
        delayMicroseconds(2);
        digitalWrite(SCL, HIGH);
        delayMicroseconds(4);
        digitalWrite(SCL, LOW);
        delayMicroseconds(2);
        data = data >> 1;  
    }

    digitalWrite(SDATA, HIGH);
    delayMicroseconds(2);
    digitalWrite(SCL, HIGH);
    delayMicroseconds(4);
    digitalWrite(SCL, LOW);
    delayMicroseconds(2);
    digitalWrite(SDATA, LOW);
    delayMicroseconds(2);
    digitalWrite(SCL, HIGH);
    delayMicroseconds(2);
    digitalWrite(SDATA, HIGH);
}

// write reg list method
void OV7670::writeReglist(const struct regval_list reglist[]){
  uint8_t reg_addr, reg_val;
  const struct regval_list *next = reglist;
  reg_addr = pgm_read_byte(&next->reg_num);
  reg_val = pgm_read_byte(&next->value);
  while ((reg_addr != 0xff) | (reg_val != 0xff)){
    OV7670::writeReg(reg_addr, reg_val);
    next++;
    reg_addr = pgm_read_byte(&next->reg_num);
    reg_val = pgm_read_byte(&next->value);
  }
}

// begin method
void OV7670::begin(){
    
    //init pins
    OV7670::initState();

    //rst fpga
    delay(20);
    digitalWrite(FP_RST, LOW);

    //config camera
    OV7670::writeReg(REG_COM7, 0x80);
    delay(10);

    //load default cam configuration
    OV7670::writeReglist(ov7670_defaul_reg);

    //update internal variable
    brightVar   = 0x00;
    contrastVar = 0x40;
    rGain       = 0x80;
    bGain       = 0x80;
    gGain       = 0x00;
    UchGain     = 0x80;
    VchGain     = 0x80;
    TSLB        = 0x04;
    COM16       = 0x10;
    EDGE        = 0x88;

    //delay to settle the value
    delay(100);
}

// set brightness method
void OV7670::setBrightness(int16_t val){
    int16_t var;
    var = (val >= 100) ? 100 :
          (val <= -100) ? -100: val;
    var = (var < 0) ? (-127 - var) : var;      
    brightVar = var & 0xff;
    OV7670::writeReg(REG_BRIGHT, brightVar);
    delay(100);
}

// get brightness value
byte OV7670::getBrightness(){
    return brightVar;
}

// set contrast method
void OV7670::setContrast(byte val){
    OV7670::writeReg(REG_CONTRAS, val);
    contrastVar = val;
    delay(100);
}

// get contrast value
byte OV7670::getContrast(){
    return contrastVar;
}

// set blue gain method
void OV7670::setBluegain(byte val){
    OV7670::writeReg(REG_BLUE, val);
    bGain = val;
    delay(100);
}

// get blue gain value
byte OV7670::getBluegain(){
    return bGain;
}

// set red gain method
void OV7670::setRedgain(byte val){
    OV7670::writeReg(REG_RED, val);
    rGain = val;
    delay(100);
}

// get red gain value
byte OV7670::getRedgain(){
    return rGain;
}

// set green gain method
void OV7670::setGreengain(byte val){
    OV7670::writeReg(GGAIN, val);
    gGain = val;
    delay(100);
}

// get green gain value
byte OV7670::getGreengain(){
    return gGain;
}

// set U-ch gain method
void OV7670::setUgain(byte val){
    TSLB = TSLB | 0x10;
    OV7670::writeReg(REG_TSLB, TSLB);
    OV7670::writeReg(MANU, val);
    UchGain = val;
    delay(100);
}

// get U-ch gain
byte OV7670::getUgain(){
    if(TSLB & 0x10) return UchGain;
    else return 0;
}

// set V-ch gain method
void OV7670::setVgain(byte val){
    TSLB = TSLB | 0x10;
    OV7670::writeReg(REG_TSLB, TSLB);
    OV7670::writeReg(MANV, val);
    VchGain = val;
    delay(100);
}

// get V-ch gain
byte OV7670::getVgain(){
    if(TSLB & 0x10) return VchGain;
    else return 0;
}

// set auto UV gain
void OV7670::setAutoUV(){
    TSLB = TSLB & 0xef;
    OV7670::writeReg(REG_TSLB, TSLB);
    delay(100);
}

// set negative image
void OV7670::setNegImage(){
    TSLB = TSLB | 0x20;
    OV7670::writeReg(REG_TSLB, TSLB);
    delay(100);
}

// reset image
void OV7670::resetImage(){
    TSLB = TSLB & 0xdf;
    OV7670::writeReg(REG_TSLB, TSLB);
    delay(100);
}

// set sharpness
void OV7670::setSharpness(byte val){
    COM16 = COM16 | 0x20;
    OV7670::writeReg(REG_COM16, COM16);
    EDGE = (val > 31) ? 31 : val;
    OV7670::writeReg(REG_EDGE, EDGE);
    delay(100);
}

// get sharpness value
byte OV7670::getSharpness(){
    if(COM16 & 0x20) return EDGE;
    else return 0;
}
