// C++ program to include the
// custom header file

#include "SPI_master.h"
  
SPIMaster::SPIMaster(byte CS, byte SCLK, byte MOSI, byte MISO)
{
    this->CS = CS;
    this->SCLK = SCLK;
    this->MOSI = MOSI;
    this->MISO = MISO;
}
  
//begin method
void SPIMaster::begin()
{
  pinMode(CS, OUTPUT);
  pinMode(SCLK, OUTPUT);
  pinMode(MOSI, OUTPUT);
  pinMode(MISO, INPUT);
  SPIMaster::defaultState();
}
  
//default state
void SPIMaster::defaultState()
{
  digitalWrite(CS, HIGH);
  digitalWrite(SCLK, LOW);
  digitalWrite(MOSI, LOW);
}
  
// transfer data
uint8_t SPIMaster::transfer(uint8_t dt)
{
  int i;
  int val = 0;
  uint16_t rx_data = 0x00;
  uint8_t data = 0x80;
  SPIMaster::defaultState();
  digitalWrite(CS, LOW);

  for(i=0; i<8; i++){
    digitalWrite(SCLK, HIGH); //tranfer data at pos edge
    if(data & dt) digitalWrite(MOSI, HIGH);
    else          digitalWrite(MOSI, LOW);
    digitalWrite(SCLK, LOW); //recv data at neg edge
    if(digitalRead(MISO) == 1) rx_data |= 0x01;
    rx_data = rx_data << 1;
    data = data>>1;
  }

  SPIMaster::defaultState();
  //recv data needs 7 left sift, to compensate one right
  //shift is done in the time of data return
  return ((rx_data>>1) & 0xff);
}
  
