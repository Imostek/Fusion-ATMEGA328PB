#ifndef UTILITY_H
#define UTILITY_H

#include <avr/pgmspace.h>

#define L1  14
#define L2  13
#define L3  11
#define L4  7

// #define _CS   2 
// #define _SCLK 3 
// #define _MOSI 4 
// #define _MISO 7 

#define _CS   19 //pc5
#define _SCLK 18 //pc4
#define _MOSI 17 //pc3
#define _MISO 16 //pc2


#endif