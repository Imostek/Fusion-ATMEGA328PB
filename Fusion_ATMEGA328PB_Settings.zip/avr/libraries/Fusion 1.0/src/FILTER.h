#ifndef FILTER_H
#define FILTER_H

#include <SPI_master.h>
  
class FILTER {
private:
    SPIMaster* spimaster;
    uint16_t coeff_0;
    uint16_t coeff_1;
    uint16_t coeff_2;
    uint16_t coeff_3;
    uint16_t coeff_4;
    uint16_t coeff_5;
    uint16_t coeff_6;
  
public:
    FILTER(SPIMaster*);
    void begin();
    void updateCoeff(byte, uint16_t);
    void setCoeff();
    uint16_t getCoeff(byte);
};
  
#endif