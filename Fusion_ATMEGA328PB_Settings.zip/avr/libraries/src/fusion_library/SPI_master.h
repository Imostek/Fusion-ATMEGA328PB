#ifndef SPI_MASTER_H
#define SPI_MASTER_H

#include <Arduino.h>
  
class SPIMaster {
private:
    byte CS;
    byte SCLK;
    byte MOSI;
    byte MISO;
  
public:
    SPIMaster(byte, byte, byte, byte);
    void begin();
    void defaultState();
    uint8_t transfer(uint8_t );
};
  
#endif